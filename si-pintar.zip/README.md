# Si Pintar 🐥

Aplikasi belajar anak (2+ tahun) berbahasa Indonesia bersama maskot **Pipi**.

- 📚 Kenalan: kartu hewan, buah, benda, warna, angka, huruf, bentuk — dengan suara
- 🎯 Main Tebak: kuis adaptif (pilihan bertambah saat anak makin pintar)
- 🎤 Ayo Bicara: anak mengucapkan nama gambar, Pipi mendengarkan
- 📷 Kamera Ajaib: foto benda, Pipi menebak namanya
- 👨‍👩‍👧 Halaman orang tua: tekan lama ⭐ di beranda

## Download APK
Buka tab **Releases** di repo ini, download `SiPintar.apk`, lalu instal.
APK dibuat otomatis oleh GitHub Actions setiap ada perubahan kode.

import 'package:flutter/material.dart';

import '../data/content.dart';
import '../services/progress.dart';
import '../services/voice.dart';
import '../widgets/pipi.dart';
import 'camera_screen.dart';
import 'category_screen.dart';
import 'progress_screen.dart';
import 'speak_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      Voice.instance.say('Halo! Aku Pipi. Ayo belajar bersama!');
    });
  }

  Future<void> _open(Widget page) async {
    await Voice.instance.stop();
    if (!mounted) return;
    await Navigator.push(context, MaterialPageRoute(builder: (_) => page));
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: CustomScrollView(
          slivers: [
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
                child: Row(
                  children: [
                    const Text('Si Pintar',
                        style: TextStyle(
                            fontSize: 30,
                            fontWeight: FontWeight.w900,
                            color: Color(0xFF5D4037))),
                    const Spacer(),
                    GestureDetector(
                      onLongPress: () => _open(const ProgressScreen()),
                      child: Chip(
                        avatar: const Text('⭐'),
                        label: Text('${Progress.instance.stars}',
                            style: const TextStyle(
                                fontSize: 18, fontWeight: FontWeight.bold)),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            SliverToBoxAdapter(
              child: GestureDetector(
                onTap: () => Voice.instance.say('Halo! Mau belajar apa hari ini?'),
                child: const Padding(
                  padding: EdgeInsets.symmetric(vertical: 8),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Pipi(size: 130, mood: PipiMood.happy),
                      SizedBox(width: 8),
                      Flexible(child: SpeechBubble('Ayo belajar\nbersama Pipi!')),
                    ],
                  ),
                ),
              ),
            ),
            SliverPadding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              sliver: SliverToBoxAdapter(
                child: Row(
                  children: [
                    Expanded(
                      child: _BigButton(
                        icon: '🎤',
                        title: 'Ayo Bicara',
                        color: const Color(0xFFFF8A65),
                        onTap: () => _open(const SpeakScreen()),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: _BigButton(
                        icon: '📷',
                        title: 'Kamera Ajaib',
                        color: const Color(0xFF4FC3F7),
                        onTap: () => _open(const CameraScreen()),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            SliverPadding(
              padding: const EdgeInsets.all(16),
              sliver: SliverGrid(
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  mainAxisSpacing: 12,
                  crossAxisSpacing: 12,
                  childAspectRatio: 1.1,
                ),
                delegate: SliverChildBuilderDelegate(
                  (context, i) {
                    final c = categories[i];
                    return _BigButton(
                      icon: c.icon,
                      title: c.title,
                      color: c.color,
                      progress: Progress.instance.categoryScore(c),
                      onTap: () {
                        Voice.instance.say(c.title);
                        _open(CategoryScreen(category: c));
                      },
                    );
                  },
                  childCount: categories.length,
                ),
              ),
            ),
            const SliverToBoxAdapter(
              child: Padding(
                padding: EdgeInsets.only(bottom: 16),
                child: Center(
                  child: Text('Orang tua: tekan lama ⭐ untuk melihat kemajuan',
                      style: TextStyle(color: Colors.black38)),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _BigButton extends StatelessWidget {
  final String icon;
  final String title;
  final Color color;
  final double? progress;
  final VoidCallback onTap;

  const _BigButton({
    required this.icon,
    required this.title,
    required this.color,
    required this.onTap,
    this.progress,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: color,
      borderRadius: BorderRadius.circular(28),
      elevation: 3,
      child: InkWell(
        borderRadius: BorderRadius.circular(28),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(icon, style: const TextStyle(fontSize: 48)),
              const SizedBox(height: 6),
              Text(title,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.w800,
                      color: Colors.white)),
              if (progress != null) ...[
                const SizedBox(height: 8),
                ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: LinearProgressIndicator(
                    value: progress,
                    minHeight: 8,
                    backgroundColor: Colors.white30,
                    valueColor: const AlwaysStoppedAnimation(Colors.white),
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}

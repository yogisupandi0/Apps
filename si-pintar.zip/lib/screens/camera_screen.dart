import 'dart:io';

import 'package:flutter/material.dart';
import 'package:google_mlkit_image_labeling/google_mlkit_image_labeling.dart';
import 'package:image_picker/image_picker.dart';

import '../data/content.dart';
import '../services/voice.dart';
import '../widgets/pipi.dart';

/// Kamera ajaib: foto benda di sekitar, Pipi menebak namanya.
class CameraScreen extends StatefulWidget {
  const CameraScreen({super.key});

  @override
  State<CameraScreen> createState() => _CameraScreenState();
}

class _CameraScreenState extends State<CameraScreen> {
  final ImagePicker _picker = ImagePicker();
  final ImageLabeler _labeler =
      ImageLabeler(options: ImageLabelerOptions(confidenceThreshold: 0.55));

  File? _photo;
  bool _busy = false;
  String _message = 'Foto benda di sekitarmu, Pipi akan menebak!';
  PipiMood _mood = PipiMood.normal;
  List<String> _guesses = [];

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback(
        (_) => Voice.instance.say('Ayo foto benda di sekitarmu!'));
  }

  @override
  void dispose() {
    _labeler.close();
    super.dispose();
  }

  Future<void> _take(ImageSource source) async {
    try {
      final x = await _picker.pickImage(
          source: source, maxWidth: 1024, imageQuality: 85);
      if (x == null) return;
      setState(() {
        _photo = File(x.path);
        _busy = true;
        _guesses = [];
        _mood = PipiMood.listening;
        _message = 'Hmm... Pipi sedang berpikir...';
      });
      final labels = await _labeler.processImage(InputImage.fromFilePath(x.path));
      final found = <String>[];
      for (final l in labels) {
        final id = cameraLabels[l.label.toLowerCase()];
        if (id != null && !found.contains(id)) found.add(id);
      }
      if (!mounted) return;
      if (found.isEmpty) {
        setState(() {
          _mood = PipiMood.sad;
          _message = 'Pipi belum tahu ini apa. Coba foto yang lain!';
        });
        await Voice.instance.say('Wah, Pipi belum tahu ini apa. Coba foto yang lain ya!');
      } else {
        setState(() {
          _mood = PipiMood.happy;
          _guesses = found.take(3).toList();
          _message = 'Ini ${found.first}!';
        });
        await Voice.instance.say('Wah! Ini ${found.first}!');
      }
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _mood = PipiMood.sad;
        _message = 'Kamera belum bisa dibuka. Coba lagi ya.';
      });
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('📷 Kamera Ajaib')),
      body: SafeArea(
        child: Column(
          children: [
            const SizedBox(height: 8),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Pipi(size: 100, mood: _mood),
                const SizedBox(width: 8),
                Flexible(child: SpeechBubble(_message)),
              ],
            ),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(32),
                  child: Container(
                    color: Colors.white,
                    width: double.infinity,
                    child: _photo == null
                        ? const Center(
                            child: Text('📸', style: TextStyle(fontSize: 120)))
                        : Stack(
                            fit: StackFit.expand,
                            children: [
                              Image.file(_photo!, fit: BoxFit.cover),
                              if (_busy)
                                const Center(child: CircularProgressIndicator()),
                            ],
                          ),
                  ),
                ),
              ),
            ),
            if (_guesses.isNotEmpty)
              Wrap(
                spacing: 8,
                children: [
                  for (final g in _guesses)
                    ActionChip(
                      label: Text(g, style: const TextStyle(fontSize: 20)),
                      onPressed: () => Voice.instance.say(g),
                    ),
                ],
              ),
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 12, 20, 28),
              child: Row(
                children: [
                  Expanded(
                    child: FilledButton.icon(
                      style: FilledButton.styleFrom(
                          padding: const EdgeInsets.symmetric(vertical: 20)),
                      onPressed: _busy ? null : () => _take(ImageSource.camera),
                      icon: const Icon(Icons.camera_alt_rounded, size: 32),
                      label: const Text('Foto', style: TextStyle(fontSize: 22)),
                    ),
                  ),
                  const SizedBox(width: 12),
                  IconButton.filledTonal(
                    iconSize: 32,
                    onPressed: _busy ? null : () => _take(ImageSource.gallery),
                    icon: const Icon(Icons.photo_library_rounded),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

import 'package:flutter/material.dart';

import '../data/content.dart';
import '../services/progress.dart';

/// Halaman orang tua: kemajuan tiap kategori dan item yang perlu dilatih.
class ProgressScreen extends StatefulWidget {
  const ProgressScreen({super.key});

  @override
  State<ProgressScreen> createState() => _ProgressScreenState();
}

class _ProgressScreenState extends State<ProgressScreen> {
  @override
  Widget build(BuildContext context) {
    final p = Progress.instance;
    return Scaffold(
      appBar: AppBar(title: const Text('Kemajuan Anak')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text('Total bintang: ⭐ ${p.stars}',
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          for (final c in categories) ...[
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Text('${c.icon} ${c.title}',
                            style: const TextStyle(
                                fontSize: 18, fontWeight: FontWeight.bold)),
                        const Spacer(),
                        Text('Level ${p.level(c.id)}'),
                      ],
                    ),
                    const SizedBox(height: 8),
                    LinearProgressIndicator(
                      value: p.categoryScore(c),
                      minHeight: 10,
                      color: c.color,
                      backgroundColor: Colors.black12,
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'Perlu latihan: ${c.items.where((i) => p.mastery(c.id, i.name) < 3).map((i) => i.name).take(6).join(', ')}',
                      style: const TextStyle(color: Colors.black54),
                    ),
                  ],
                ),
              ),
            ),
          ],
          const SizedBox(height: 16),
          OutlinedButton.icon(
            onPressed: () async {
              final ok = await showDialog<bool>(
                context: context,
                builder: (ctx) => AlertDialog(
                  title: const Text('Hapus semua kemajuan?'),
                  actions: [
                    TextButton(
                        onPressed: () => Navigator.pop(ctx, false),
                        child: const Text('Batal')),
                    TextButton(
                        onPressed: () => Navigator.pop(ctx, true),
                        child: const Text('Hapus')),
                  ],
                ),
              );
              if (ok == true) {
                await p.reset();
                if (mounted) setState(() {});
              }
            },
            icon: const Icon(Icons.restart_alt),
            label: const Text('Mulai dari awal'),
          ),
        ],
      ),
    );
  }
}

import 'dart:math';

import 'package:flutter/material.dart';
import 'package:speech_to_text/speech_recognition_result.dart';
import 'package:speech_to_text/speech_to_text.dart';

import '../data/content.dart';
import '../services/progress.dart';
import '../services/voice.dart';
import '../widgets/item_view.dart';
import '../widgets/pipi.dart';

/// Latihan bicara: Pipi menunjukkan gambar, anak mengucapkan namanya.
class SpeakScreen extends StatefulWidget {
  const SpeakScreen({super.key});

  @override
  State<SpeakScreen> createState() => _SpeakScreenState();
}

class _SpeakScreenState extends State<SpeakScreen> {
  final SpeechToText _stt = SpeechToText();
  final Random _rng = Random();
  final List<Category> _cats = categories.where((c) => c.speakable).toList();

  late Category _cat;
  late Item _item;
  bool _available = false;
  bool _listening = false;
  String _heard = '';
  String _message = 'Ketuk mikrofon, lalu ucapkan!';
  PipiMood _mood = PipiMood.normal;
  int _tries = 0;

  @override
  void initState() {
    super.initState();
    _next(speak: false);
    _initSpeech();
  }

  Future<void> _initSpeech() async {
    try {
      _available = await _stt.initialize(
        onStatus: (s) {
          if ((s == 'done' || s == 'notListening') && mounted) {
            setState(() => _listening = false);
          }
        },
        onError: (_) {
          if (mounted) setState(() => _listening = false);
        },
      );
    } catch (_) {
      _available = false;
    }
    if (!mounted) return;
    setState(() {
      if (!_available) {
        _message = 'Mikrofon belum bisa dipakai. Izinkan akses mikrofon dulu ya.';
      }
    });
    _prompt();
  }

  void _next({bool speak = true}) {
    _cat = _cats[_rng.nextInt(_cats.length)];
    _item = Progress.instance.pickItem(_cat);
    _heard = '';
    _tries = 0;
    _mood = PipiMood.normal;
    _message = 'Ketuk mikrofon, lalu ucapkan!';
    if (speak) _prompt();
  }

  void _prompt() => Voice.instance.say('Ayo ucapkan: ${_item.name}');

  String _norm(String s) =>
      s.toLowerCase().replaceAll(RegExp(r'[^a-z ]'), '').trim();

  bool _matches(String heard) {
    final target = _norm(_item.name);
    final h = _norm(heard);
    if (h.isEmpty) return false;
    if (h.contains(target)) return true;
    // toleransi pelafalan anak: cocok jika sebagian besar huruf sama
    for (final w in h.split(' ')) {
      if (_similar(w, target) >= 0.6) return true;
    }
    return false;
  }

  double _similar(String a, String b) {
    if (a.isEmpty || b.isEmpty) return 0;
    final d = List.generate(a.length + 1, (_) => List<int>.filled(b.length + 1, 0));
    for (var i = 0; i <= a.length; i++) {
      d[i][0] = i;
    }
    for (var j = 0; j <= b.length; j++) {
      d[0][j] = j;
    }
    for (var i = 1; i <= a.length; i++) {
      for (var j = 1; j <= b.length; j++) {
        final cost = a[i - 1] == b[j - 1] ? 0 : 1;
        d[i][j] = [d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + cost]
            .reduce(min);
      }
    }
    return 1 - d[a.length][b.length] / max(a.length, b.length);
  }

  Future<void> _listen() async {
    if (!_available) {
      await _initSpeech();
      if (!_available) return;
    }
    if (_listening) {
      await _stt.stop();
      return;
    }
    await Voice.instance.stop();
    setState(() {
      _listening = true;
      _heard = '';
      _mood = PipiMood.listening;
      _message = 'Pipi mendengarkan...';
    });
    await _stt.listen(
      localeId: 'id_ID',
      listenFor: const Duration(seconds: 6),
      pauseFor: const Duration(seconds: 3),
      listenOptions: SpeechListenOptions(partialResults: true, cancelOnError: true),
      onResult: _onResult,
    );
  }

  Future<void> _onResult(SpeechRecognitionResult r) async {
    if (!mounted) return;
    setState(() => _heard = r.recognizedWords);
    if (_matches(r.recognizedWords)) {
      await _stt.stop();
      await Progress.instance.record(_cat.id, _item.name, true);
      if (!mounted) return;
      setState(() {
        _listening = false;
        _mood = PipiMood.happy;
        _message = 'Hebat! Kamu bilang ${_item.name}! 🎉';
      });
      await Voice.instance.say('Hebat sekali! ${_item.name}!');
      await Future.delayed(const Duration(milliseconds: 800));
      if (mounted) setState(() => _next());
    } else if (r.finalResult) {
      _tries++;
      setState(() {
        _listening = false;
        _mood = PipiMood.normal;
        _message = _tries >= 3
            ? 'Bagus sudah mencoba! Ini ${_item.name}.'
            : 'Hampir! Coba lagi ya.';
      });
      if (_tries >= 3) {
        await Voice.instance.say('Bagus sudah mencoba! Ini ${_item.name}. Ayo yang lain.');
        await Future.delayed(const Duration(milliseconds: 600));
        if (mounted) setState(() => _next());
      } else {
        await Voice.instance.say('Hampir! Coba lagi. ${_item.name}');
      }
    }
  }

  @override
  void dispose() {
    _stt.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('🎤 Ayo Bicara')),
      body: SafeArea(
        child: Column(
          children: [
            const SizedBox(height: 8),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Pipi(size: 100, mood: _mood),
                const SizedBox(width: 8),
                Flexible(child: SpeechBubble(_message)),
              ],
            ),
            Expanded(
              child: GestureDetector(
                onTap: _prompt,
                child: Card(
                  margin: const EdgeInsets.all(24),
                  color: Colors.white,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(36)),
                  child: Center(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        ItemView(_item, size: 180),
                        const SizedBox(height: 16),
                        Text(_item.name,
                            style: const TextStyle(
                                fontSize: 40,
                                fontWeight: FontWeight.w900,
                                color: Color(0xFF5D4037))),
                        if (_heard.isNotEmpty)
                          Padding(
                            padding: const EdgeInsets.only(top: 8),
                            child: Text('Terdengar: "$_heard"',
                                style: const TextStyle(
                                    fontSize: 18, color: Colors.black45)),
                          ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(bottom: 32),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  IconButton.filledTonal(
                    iconSize: 36,
                    onPressed: () => setState(() => _next()),
                    icon: const Icon(Icons.skip_next_rounded),
                  ),
                  GestureDetector(
                    onTap: _listen,
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 300),
                      width: _listening ? 120 : 100,
                      height: _listening ? 120 : 100,
                      decoration: BoxDecoration(
                        color: _listening
                            ? const Color(0xFFE53935)
                            : const Color(0xFFFF8A65),
                        shape: BoxShape.circle,
                        boxShadow: const [
                          BoxShadow(color: Color(0x33000000), blurRadius: 10)
                        ],
                      ),
                      child: Icon(
                          _listening ? Icons.stop_rounded : Icons.mic_rounded,
                          size: 56,
                          color: Colors.white),
                    ),
                  ),
                  IconButton.filledTonal(
                    iconSize: 36,
                    onPressed: _prompt,
                    icon: const Icon(Icons.volume_up_rounded),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

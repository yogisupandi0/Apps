import 'package:flutter/material.dart';

import '../data/content.dart';
import '../services/progress.dart';
import '../services/voice.dart';
import '../widgets/item_view.dart';
import '../widgets/pipi.dart';

/// Satu kategori: mode "Kenalan" (kartu) dan "Main Tebak" (kuis adaptif).
class CategoryScreen extends StatelessWidget {
  final Category category;
  const CategoryScreen({super.key, required this.category});

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: Text('${category.icon} ${category.title}'),
          bottom: const TabBar(
            labelStyle: TextStyle(fontSize: 18, fontWeight: FontWeight.w800),
            tabs: [Tab(text: '📚 Kenalan'), Tab(text: '🎯 Main Tebak')],
          ),
        ),
        body: TabBarView(
          physics: const NeverScrollableScrollPhysics(),
          children: [
            _LearnView(category: category),
            _QuizView(category: category),
          ],
        ),
      ),
    );
  }
}

class _LearnView extends StatefulWidget {
  final Category category;
  const _LearnView({required this.category});

  @override
  State<_LearnView> createState() => _LearnViewState();
}

class _LearnViewState extends State<_LearnView> {
  late final PageController _pc = PageController();
  int _index = 0;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _speak());
  }

  @override
  void dispose() {
    _pc.dispose();
    super.dispose();
  }

  void _speak() {
    final item = widget.category.items[_index];
    Voice.instance.say('Ini ${item.name}');
  }

  void _go(int delta) {
    final n = widget.category.items.length;
    final next = (_index + delta) % n;
    _pc.animateToPage(next < 0 ? next + n : next,
        duration: const Duration(milliseconds: 350), curve: Curves.easeOut);
  }

  @override
  Widget build(BuildContext context) {
    final items = widget.category.items;
    return Column(
      children: [
        Expanded(
          child: PageView.builder(
            controller: _pc,
            itemCount: items.length,
            onPageChanged: (i) {
              setState(() => _index = i);
              _speak();
            },
            itemBuilder: (context, i) {
              final item = items[i];
              return GestureDetector(
                onTap: _speak,
                child: Card(
                  margin: const EdgeInsets.all(24),
                  color: Colors.white,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(36)),
                  elevation: 4,
                  child: Center(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        ItemView(item, size: 200),
                        const SizedBox(height: 24),
                        Text(item.name,
                            style: TextStyle(
                                fontSize: 44,
                                fontWeight: FontWeight.w900,
                                color: widget.category.color)),
                        const SizedBox(height: 8),
                        const Text('Ketuk untuk dengar 🔊',
                            style: TextStyle(color: Colors.black38)),
                      ],
                    ),
                  ),
                ),
              );
            },
          ),
        ),
        Padding(
          padding: const EdgeInsets.only(bottom: 24),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              _RoundButton(icon: Icons.arrow_back_rounded, onTap: () => _go(-1)),
              Text('${_index + 1} / ${items.length}',
                  style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
              _RoundButton(icon: Icons.arrow_forward_rounded, onTap: () => _go(1)),
            ],
          ),
        ),
      ],
    );
  }
}

class _QuizView extends StatefulWidget {
  final Category category;
  const _QuizView({required this.category});

  @override
  State<_QuizView> createState() => _QuizViewState();
}

class _QuizViewState extends State<_QuizView>
    with AutomaticKeepAliveClientMixin {
  late Item _answer;
  late List<Item> _options;
  PipiMood _mood = PipiMood.normal;
  Item? _wrongPick;
  bool _locked = false;
  bool _started = false;

  @override
  bool get wantKeepAlive => true;

  @override
  void initState() {
    super.initState();
    _newQuestion(speak: false);
  }

  void _newQuestion({bool speak = true, Item? avoid}) {
    final p = Progress.instance;
    _answer = p.pickItem(widget.category, avoid: avoid);
    _options = p.optionsFor(widget.category, _answer);
    _mood = PipiMood.normal;
    _wrongPick = null;
    _locked = false;
    if (speak) _ask();
  }

  void _ask() => Voice.instance.say('Mana ${_answer.name}?');

  Future<void> _pick(Item item) async {
    if (_locked) return;
    final correct = item == _answer;
    await Progress.instance.record(widget.category.id, _answer.name, correct);
    if (!mounted) return;
    if (correct) {
      setState(() {
        _mood = PipiMood.happy;
        _locked = true;
      });
      await Voice.instance.say('Hebat! Itu ${_answer.name}!');
      await Future.delayed(const Duration(milliseconds: 600));
      if (!mounted) return;
      setState(() => _newQuestion(avoid: _answer));
    } else {
      setState(() {
        _mood = PipiMood.sad;
        _wrongPick = item;
      });
      await Voice.instance.say('Itu ${item.name}. Coba lagi, mana ${_answer.name}?');
      if (mounted) setState(() => _mood = PipiMood.normal);
    }
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    if (!_started) {
      return Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Pipi(size: 160),
            const SizedBox(height: 16),
            FilledButton.icon(
              style: FilledButton.styleFrom(
                  padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 20)),
              onPressed: () {
                setState(() => _started = true);
                _ask();
              },
              icon: const Icon(Icons.play_arrow_rounded, size: 36),
              label: const Text('Mulai', style: TextStyle(fontSize: 26)),
            ),
          ],
        ),
      );
    }
    final level = Progress.instance.level(widget.category.id);
    final cols = _options.length <= 2 ? 1 : 2;
    return Column(
      children: [
        const SizedBox(height: 8),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Pipi(size: 100, mood: _mood),
            const SizedBox(width: 8),
            GestureDetector(
              onTap: _ask,
              child: SpeechBubble('Mana ${_answer.name}? 🔊'),
            ),
          ],
        ),
        Text('Level ${'⭐' * level}', style: const TextStyle(fontSize: 18)),
        Expanded(
          child: GridView.count(
            padding: const EdgeInsets.all(16),
            crossAxisCount: cols,
            mainAxisSpacing: 16,
            crossAxisSpacing: 16,
            childAspectRatio: cols == 1 ? 1.8 : 1,
            children: [
              for (final o in _options)
                Material(
                  color: o == _wrongPick
                      ? const Color(0xFFFFCDD2)
                      : (_locked && o == _answer)
                          ? const Color(0xFFC8E6C9)
                          : Colors.white,
                  borderRadius: BorderRadius.circular(28),
                  elevation: 3,
                  child: InkWell(
                    borderRadius: BorderRadius.circular(28),
                    onTap: () => _pick(o),
                    child: Center(child: ItemView(o, size: 110)),
                  ),
                ),
            ],
          ),
        ),
      ],
    );
  }
}

class _RoundButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  const _RoundButton({required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: const Color(0xFFFFB300),
      shape: const CircleBorder(),
      elevation: 3,
      child: InkWell(
        customBorder: const CircleBorder(),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(18),
          child: Icon(icon, size: 40, color: Colors.white),
        ),
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'screens/home_screen.dart';
import 'services/progress.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  await Progress.instance.load();
  runApp(const SiPintarApp());
}

class SiPintarApp extends StatelessWidget {
  const SiPintarApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Si Pintar',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFFFFB300)),
        scaffoldBackgroundColor: const Color(0xFFFFF8E1),
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFFFFF8E1),
          centerTitle: true,
          titleTextStyle: TextStyle(
              fontSize: 24, fontWeight: FontWeight.w800, color: Color(0xFF5D4037)),
        ),
      ),
      home: const HomeScreen(),
    );
  }
}

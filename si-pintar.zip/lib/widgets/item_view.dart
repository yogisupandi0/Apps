import 'package:flutter/material.dart';

import '../data/content.dart';

/// Menampilkan gambar item: emoji, angka/huruf besar, atau lingkaran warna.
class ItemView extends StatelessWidget {
  final Item item;
  final double size;

  const ItemView(this.item, {super.key, this.size = 160});

  @override
  Widget build(BuildContext context) {
    if (item.color != null) {
      return Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          color: item.color,
          shape: BoxShape.circle,
          border: Border.all(color: Colors.black12, width: 4),
        ),
      );
    }
    final isText = RegExp(r'^[A-Z0-9]+$').hasMatch(item.display);
    return SizedBox(
      width: size,
      height: size,
      child: FittedBox(
        child: Text(
          item.display,
          style: TextStyle(
            fontSize: 120,
            fontWeight: FontWeight.w900,
            color: isText ? const Color(0xFF5C6BC0) : null,
          ),
        ),
      ),
    );
  }
}

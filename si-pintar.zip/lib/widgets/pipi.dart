import 'dart:math';

import 'package:flutter/material.dart';

enum PipiMood { normal, happy, sad, listening }

/// Pipi: maskot anak ayam kuning yang memantul, berkedip, dan mengepakkan sayap.
class Pipi extends StatefulWidget {
  final double size;
  final PipiMood mood;

  const Pipi({super.key, this.size = 140, this.mood = PipiMood.normal});

  @override
  State<Pipi> createState() => _PipiState();
}

class _PipiState extends State<Pipi> with TickerProviderStateMixin {
  late final AnimationController _bounce;
  late final AnimationController _blink;

  @override
  void initState() {
    super.initState();
    _bounce = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 1400))
      ..repeat();
    _blink = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 3200))
      ..repeat();
  }

  @override
  void dispose() {
    _bounce.dispose();
    _blink.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: widget.size,
      height: widget.size,
      child: AnimatedBuilder(
        animation: Listenable.merge([_bounce, _blink]),
        builder: (context, _) {
          final speed = widget.mood == PipiMood.happy ? 2.0 : 1.0;
          final t = (_bounce.value * speed) % 1.0;
          final hop = widget.mood == PipiMood.sad
              ? 0.0
              : sin(t * 2 * pi).abs() * (widget.mood == PipiMood.happy ? 0.12 : 0.05);
          final blinking = _blink.value > 0.95;
          return CustomPaint(
            painter: _PipiPainter(
              hop: hop,
              wing: sin(t * 2 * pi),
              blinking: blinking,
              mood: widget.mood,
            ),
          );
        },
      ),
    );
  }
}

class _PipiPainter extends CustomPainter {
  final double hop;
  final double wing;
  final bool blinking;
  final PipiMood mood;

  _PipiPainter({
    required this.hop,
    required this.wing,
    required this.blinking,
    required this.mood,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final s = size.width;
    final cx = s / 2;
    final cy = s * 0.56 - hop * s;

    // bayangan
    canvas.drawOval(
      Rect.fromCenter(
          center: Offset(cx, s * 0.95),
          width: s * (0.55 - hop),
          height: s * 0.07),
      Paint()..color = Colors.black.withOpacity(0.12),
    );

    final body = Paint()..color = const Color(0xFFFFD54F);
    final bodyDark = Paint()..color = const Color(0xFFFFB300);
    final orange = Paint()..color = const Color(0xFFFF8F00);

    // kaki
    final legPaint = Paint()
      ..color = orange.color
      ..strokeWidth = s * 0.035
      ..strokeCap = StrokeCap.round;
    for (final dx in [-0.1, 0.1]) {
      final x = cx + dx * s;
      canvas.drawLine(Offset(x, cy + s * 0.3), Offset(x, cy + s * 0.37), legPaint);
      canvas.drawLine(Offset(x, cy + s * 0.37),
          Offset(x - s * 0.04, cy + s * 0.4), legPaint);
      canvas.drawLine(Offset(x, cy + s * 0.37),
          Offset(x + s * 0.04, cy + s * 0.4), legPaint);
    }

    // sayap
    final flap = mood == PipiMood.happy ? wing * 0.5 : wing * 0.12;
    for (final side in [-1.0, 1.0]) {
      canvas.save();
      canvas.translate(cx + side * s * 0.32, cy + s * 0.05);
      canvas.rotate(side * (0.4 + flap));
      canvas.drawOval(
          Rect.fromCenter(
              center: Offset(side * s * 0.05, 0),
              width: s * 0.18,
              height: s * 0.3),
          bodyDark);
      canvas.restore();
    }

    // badan
    canvas.drawOval(
        Rect.fromCenter(
            center: Offset(cx, cy), width: s * 0.66, height: s * 0.66),
        body);

    // jambul
    final tuft = Path()
      ..moveTo(cx - s * 0.04, cy - s * 0.31)
      ..quadraticBezierTo(cx - s * 0.08, cy - s * 0.45, cx, cy - s * 0.4)
      ..quadraticBezierTo(cx + s * 0.08, cy - s * 0.47, cx + s * 0.05, cy - s * 0.31)
      ..close();
    canvas.drawPath(tuft, bodyDark);

    // pipi merah
    final blush = Paint()..color = const Color(0xFFFF8A80).withOpacity(0.7);
    canvas.drawCircle(Offset(cx - s * 0.2, cy + s * 0.04), s * 0.05, blush);
    canvas.drawCircle(Offset(cx + s * 0.2, cy + s * 0.04), s * 0.05, blush);

    // mata
    final eye = Paint()..color = const Color(0xFF3E2723);
    final eyeY = cy - s * 0.07;
    for (final dx in [-0.12, 0.12]) {
      final c = Offset(cx + dx * s, eyeY);
      if (blinking || mood == PipiMood.happy) {
        final p = Paint()
          ..color = eye.color
          ..style = PaintingStyle.stroke
          ..strokeWidth = s * 0.025
          ..strokeCap = StrokeCap.round;
        final r = Rect.fromCenter(center: c, width: s * 0.1, height: s * 0.08);
        if (mood == PipiMood.happy) {
          canvas.drawArc(r, pi, pi, false, p); // mata senyum ^ ^
        } else {
          canvas.drawLine(c - Offset(s * 0.045, 0), c + Offset(s * 0.045, 0), p);
        }
      } else {
        canvas.drawCircle(c, s * 0.05, eye);
        canvas.drawCircle(c + Offset(s * 0.018, -s * 0.018), s * 0.017,
            Paint()..color = Colors.white);
      }
    }
    if (mood == PipiMood.sad) {
      final brow = Paint()
        ..color = eye.color
        ..strokeWidth = s * 0.018
        ..strokeCap = StrokeCap.round;
      canvas.drawLine(Offset(cx - s * 0.17, eyeY - s * 0.07),
          Offset(cx - s * 0.08, eyeY - s * 0.1), brow);
      canvas.drawLine(Offset(cx + s * 0.17, eyeY - s * 0.07),
          Offset(cx + s * 0.08, eyeY - s * 0.1), brow);
    }

    // paruh
    final open = mood == PipiMood.happy || mood == PipiMood.listening;
    final beakTop = Path()
      ..moveTo(cx - s * 0.06, cy + s * 0.02)
      ..lineTo(cx + s * 0.06, cy + s * 0.02)
      ..lineTo(cx, cy + s * 0.08)
      ..close();
    canvas.drawPath(beakTop, orange);
    if (open) {
      final beakBottom = Path()
        ..moveTo(cx - s * 0.045, cy + s * 0.07)
        ..lineTo(cx + s * 0.045, cy + s * 0.07)
        ..lineTo(cx, cy + s * 0.12)
        ..close();
      canvas.drawPath(beakBottom, Paint()..color = const Color(0xFFE65100));
    }
  }

  @override
  bool shouldRepaint(covariant _PipiPainter old) =>
      old.hop != hop ||
      old.wing != wing ||
      old.blinking != blinking ||
      old.mood != mood;
}

/// Gelembung kata di samping Pipi.
class SpeechBubble extends StatelessWidget {
  final String text;
  const SpeechBubble(this.text, {super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: const [
          BoxShadow(color: Color(0x22000000), blurRadius: 8, offset: Offset(0, 3))
        ],
      ),
      child: Text(
        text,
        style: const TextStyle(
            fontSize: 20, fontWeight: FontWeight.w700, color: Color(0xFF5D4037)),
      ),
    );
  }
}

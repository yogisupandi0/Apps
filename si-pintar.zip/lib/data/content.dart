import 'package:flutter/material.dart';

/// Satu hal yang dipelajari anak: nama (diucapkan) dan gambar (emoji/teks).
class Item {
  final String name;
  final String display;
  final Color? color; // dipakai untuk kategori Warna

  const Item(this.name, this.display, {this.color});
}

class Category {
  final String id;
  final String title;
  final String icon;
  final Color color;
  final List<Item> items;
  final bool speakable; // cocok untuk latihan bicara

  const Category({
    required this.id,
    required this.title,
    required this.icon,
    required this.color,
    required this.items,
    this.speakable = true,
  });
}

const List<Category> categories = [
  Category(
    id: 'hewan',
    title: 'Hewan',
    icon: '🐱',
    color: Color(0xFFFFB74D),
    items: [
      Item('Kucing', '🐱'),
      Item('Anjing', '🐶'),
      Item('Sapi', '🐮'),
      Item('Ayam', '🐔'),
      Item('Ikan', '🐟'),
      Item('Gajah', '🐘'),
      Item('Kelinci', '🐰'),
      Item('Bebek', '🦆'),
      Item('Kuda', '🐴'),
      Item('Monyet', '🐵'),
      Item('Burung', '🐦'),
      Item('Kambing', '🐐'),
    ],
  ),
  Category(
    id: 'buah',
    title: 'Buah',
    icon: '🍎',
    color: Color(0xFFE57373),
    items: [
      Item('Apel', '🍎'),
      Item('Pisang', '🍌'),
      Item('Jeruk', '🍊'),
      Item('Anggur', '🍇'),
      Item('Semangka', '🍉'),
      Item('Stroberi', '🍓'),
      Item('Nanas', '🍍'),
      Item('Mangga', '🥭'),
      Item('Ceri', '🍒'),
      Item('Pir', '🍐'),
    ],
  ),
  Category(
    id: 'benda',
    title: 'Benda',
    icon: '⚽',
    color: Color(0xFF64B5F6),
    items: [
      Item('Bola', '⚽'),
      Item('Mobil', '🚗'),
      Item('Rumah', '🏠'),
      Item('Buku', '📖'),
      Item('Sepatu', '👟'),
      Item('Topi', '🧢'),
      Item('Jam', '⏰'),
      Item('Kursi', '🪑'),
      Item('Pesawat', '✈️'),
      Item('Kapal', '🚢'),
    ],
  ),
  Category(
    id: 'warna',
    title: 'Warna',
    icon: '🎨',
    color: Color(0xFFBA68C8),
    items: [
      Item('Merah', '', color: Color(0xFFE53935)),
      Item('Kuning', '', color: Color(0xFFFDD835)),
      Item('Biru', '', color: Color(0xFF1E88E5)),
      Item('Hijau', '', color: Color(0xFF43A047)),
      Item('Oranye', '', color: Color(0xFFFB8C00)),
      Item('Ungu', '', color: Color(0xFF8E24AA)),
      Item('Hitam', '', color: Color(0xFF212121)),
      Item('Putih', '', color: Color(0xFFFFFFFF)),
      Item('Merah Muda', '', color: Color(0xFFF06292)),
      Item('Cokelat', '', color: Color(0xFF6D4C41)),
    ],
  ),
  Category(
    id: 'angka',
    title: 'Angka',
    icon: '🔢',
    color: Color(0xFF4DB6AC),
    speakable: false,
    items: [
      Item('Satu', '1'),
      Item('Dua', '2'),
      Item('Tiga', '3'),
      Item('Empat', '4'),
      Item('Lima', '5'),
      Item('Enam', '6'),
      Item('Tujuh', '7'),
      Item('Delapan', '8'),
      Item('Sembilan', '9'),
      Item('Sepuluh', '10'),
    ],
  ),
  Category(
    id: 'huruf',
    title: 'Huruf',
    icon: '🔤',
    color: Color(0xFF7986CB),
    speakable: false,
    items: [
      Item('A', 'A'), Item('B', 'B'), Item('C', 'C'), Item('D', 'D'),
      Item('E', 'E'), Item('F', 'F'), Item('G', 'G'), Item('H', 'H'),
      Item('I', 'I'), Item('J', 'J'), Item('K', 'K'), Item('L', 'L'),
      Item('M', 'M'), Item('N', 'N'), Item('O', 'O'), Item('P', 'P'),
      Item('Q', 'Q'), Item('R', 'R'), Item('S', 'S'), Item('T', 'T'),
      Item('U', 'U'), Item('V', 'V'), Item('W', 'W'), Item('X', 'X'),
      Item('Y', 'Y'), Item('Z', 'Z'),
    ],
  ),
  Category(
    id: 'bentuk',
    title: 'Bentuk',
    icon: '🔷',
    color: Color(0xFFAED581),
    items: [
      Item('Lingkaran', '⚪'),
      Item('Segitiga', '🔺'),
      Item('Kotak', '🟦'),
      Item('Bintang', '⭐'),
      Item('Hati', '❤️'),
      Item('Bulan', '🌙'),
    ],
  ),
];

/// Label kamera (Inggris, dari ML Kit) ke kata Indonesia.
const Map<String, String> cameraLabels = {
  'cat': 'kucing', 'dog': 'anjing', 'bird': 'burung', 'fish': 'ikan',
  'horse': 'kuda', 'cattle': 'sapi', 'cow': 'sapi', 'chicken': 'ayam',
  'duck': 'bebek', 'rabbit': 'kelinci', 'butterfly': 'kupu-kupu',
  'insect': 'serangga', 'teddy bear': 'boneka beruang', 'toy': 'mainan',
  'flower': 'bunga', 'plant': 'tanaman', 'tree': 'pohon', 'grass': 'rumput',
  'fruit': 'buah', 'food': 'makanan', 'vegetable': 'sayur', 'bread': 'roti',
  'cake': 'kue', 'car': 'mobil', 'bicycle': 'sepeda', 'motorcycle': 'motor',
  'vehicle': 'kendaraan', 'wheel': 'roda', 'ball': 'bola', 'shoe': 'sepatu',
  'hat': 'topi', 'cap': 'topi', 'bag': 'tas', 'book': 'buku', 'chair': 'kursi',
  'couch': 'sofa', 'table': 'meja', 'bed': 'kasur', 'cup': 'gelas',
  'mug': 'cangkir', 'bottle': 'botol', 'phone': 'telepon',
  'mobile phone': 'HP', 'computer': 'komputer', 'television': 'televisi',
  'clock': 'jam', 'glasses': 'kacamata', 'sky': 'langit', 'cloud': 'awan',
  'water': 'air', 'house': 'rumah', 'building': 'gedung', 'door': 'pintu',
  'window': 'jendela', 'hand': 'tangan', 'smile': 'senyum', 'person': 'orang',
  'baby': 'bayi', 'hair': 'rambut', 'balloon': 'balon', 'pillow': 'bantal',
  'umbrella': 'payung', 'sunglasses': 'kacamata hitam', 'shirt': 'baju',
  'jacket': 'jaket', 'jeans': 'celana', 'paper': 'kertas', 'pen': 'pulpen',
  'keyboard': 'papan ketik', 'lamp': 'lampu', 'sun': 'matahari',
};

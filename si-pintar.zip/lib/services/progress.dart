import 'dart:convert';
import 'dart:math';

import 'package:shared_preferences/shared_preferences.dart';

import '../data/content.dart';

/// Belajar adaptif: mencatat seberapa paham anak pada tiap item,
/// lalu memilih soal yang paling perlu dilatih dan mengatur tingkat kesulitan.
class Progress {
  Progress._();
  static final Progress instance = Progress._();

  static const _key = 'mastery_v1';
  static const _levelKey = 'level_v1';
  static const _starsKey = 'stars_v1';

  /// mastery[categoryId][itemName] = 0..5
  Map<String, Map<String, int>> _mastery = {};
  Map<String, int> _level = {};
  int stars = 0;
  SharedPreferences? _prefs;
  final Random _rng = Random();

  Future<void> load() async {
    _prefs = await SharedPreferences.getInstance();
    final raw = _prefs!.getString(_key);
    if (raw != null) {
      try {
        final decoded = jsonDecode(raw) as Map<String, dynamic>;
        _mastery = decoded.map((cat, v) => MapEntry(
            cat,
            (v as Map<String, dynamic>)
                .map((item, m) => MapEntry(item, (m as num).toInt()))));
      } catch (_) {
        _mastery = {};
      }
    }
    final rawLevel = _prefs!.getString(_levelKey);
    if (rawLevel != null) {
      try {
        _level = (jsonDecode(rawLevel) as Map<String, dynamic>)
            .map((k, v) => MapEntry(k, (v as num).toInt()));
      } catch (_) {
        _level = {};
      }
    }
    stars = _prefs!.getInt(_starsKey) ?? 0;
  }

  Future<void> _save() async {
    final p = _prefs ?? await SharedPreferences.getInstance();
    await p.setString(_key, jsonEncode(_mastery));
    await p.setString(_levelKey, jsonEncode(_level));
    await p.setInt(_starsKey, stars);
  }

  int mastery(String cat, String item) => _mastery[cat]?[item] ?? 0;

  /// Tingkat 1..3: menentukan jumlah pilihan jawaban (2, 3, atau 4).
  int level(String cat) => _level[cat] ?? 1;

  int optionCount(String cat) => level(cat) + 1;

  /// Persentase penguasaan kategori (0..1).
  double categoryScore(Category c) {
    if (c.items.isEmpty) return 0;
    final total = c.items.fold<int>(0, (s, i) => s + mastery(c.id, i.name));
    return total / (c.items.length * 5);
  }

  final Map<String, int> _streak = {};

  Future<void> record(String cat, String item, bool correct) async {
    final m = _mastery.putIfAbsent(cat, () => {});
    final cur = m[item] ?? 0;
    m[item] = correct ? min(5, cur + 1) : max(0, cur - 1);

    if (correct) {
      stars += 1;
      final s = (_streak[cat] ?? 0) + 1;
      _streak[cat] = s;
      if (s >= 4 && level(cat) < 3) {
        _level[cat] = level(cat) + 1;
        _streak[cat] = 0;
      }
    } else {
      _streak[cat] = 0;
      if (level(cat) > 1) _level[cat] = level(cat) - 1;
    }
    await _save();
  }

  /// Pilih item berikutnya: yang belum dikuasai lebih sering muncul.
  Item pickItem(Category c, {Item? avoid}) {
    final pool = c.items.where((i) => i != avoid).toList();
    final weights = pool.map((i) => 6 - mastery(c.id, i.name)).toList();
    final total = weights.fold<int>(0, (a, b) => a + b);
    var r = _rng.nextInt(total);
    for (var k = 0; k < pool.length; k++) {
      r -= weights[k];
      if (r < 0) return pool[k];
    }
    return pool.last;
  }

  List<Item> optionsFor(Category c, Item answer) {
    final others = c.items.where((i) => i != answer).toList()..shuffle(_rng);
    final n = min(optionCount(c.id), c.items.length);
    final opts = [answer, ...others.take(n - 1)]..shuffle(_rng);
    return opts;
  }

  Future<void> reset() async {
    _mastery = {};
    _level = {};
    _streak.clear();
    stars = 0;
    await _save();
  }
}

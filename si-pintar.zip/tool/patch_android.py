"""Menyesuaikan proyek Android hasil `flutter create` untuk Si Pintar."""
import pathlib
import re

root = pathlib.Path(__file__).resolve().parent.parent
manifest = root / "android/app/src/main/AndroidManifest.xml"
text = manifest.read_text()

perms = """    <uses-permission android:name="android.permission.INTERNET"/>
    <uses-permission android:name="android.permission.RECORD_AUDIO"/>
    <uses-permission android:name="android.permission.BLUETOOTH"/>
    <uses-permission android:name="android.permission.BLUETOOTH_ADMIN"/>
    <uses-permission android:name="android.permission.BLUETOOTH_CONNECT"/>
    <queries>
        <intent>
            <action android:name="android.speech.RecognitionService"/>
        </intent>
        <intent>
            <action android:name="android.intent.action.TTS_SERVICE"/>
        </intent>
        <intent>
            <action android:name="android.media.action.IMAGE_CAPTURE"/>
        </intent>
    </queries>
"""
if "RECORD_AUDIO" not in text:
    text = text.replace("    <application", perms + "    <application", 1)
text = re.sub(r'android:label="[^"]*"', 'android:label="Si Pintar"', text, count=1)
manifest.write_text(text)

for name in ("build.gradle.kts", "build.gradle"):
    gradle = root / "android/app" / name
    if gradle.exists():
        g = gradle.read_text()
        g = g.replace("minSdk = flutter.minSdkVersion", "minSdk = 24")
        g = g.replace("minSdkVersion flutter.minSdkVersion", "minSdkVersion 24")
        gradle.write_text(g)
        print("patched", gradle)

print(manifest.read_text())
